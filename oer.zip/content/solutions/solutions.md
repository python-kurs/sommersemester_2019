# Solutions

Here you will find the solutions for our weekly exercises.
