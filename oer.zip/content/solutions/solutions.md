# Solutions

Here you will find the solutions for our the weekly exercises.
